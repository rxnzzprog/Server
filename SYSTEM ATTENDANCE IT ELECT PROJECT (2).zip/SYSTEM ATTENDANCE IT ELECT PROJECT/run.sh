#!/usr/bin/env bash

# ==============================================================================
# QR Code Attendance Management System - Linux Server Runner
# ==============================================================================
# Cross-compatible runner script designed for Linux environments
# (Ubuntu, Debian, CentOS, RHEL, AlmaLinux, Rocky, Arch, etc.)
# ==============================================================================

# Ensure script runs from the repository root directory
cd "$(dirname "$0")" || exit 1
APP_DIR="$(pwd)"
PID_FILE="$APP_DIR/.server.pid"
LOG_FILE="$APP_DIR/server.log"

# Color Codes
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
BOLD='\033[1m'
NC='\033[0m' # No Color

# ------------------------------------------------------------------------------
# Helper Functions
# ------------------------------------------------------------------------------
log_info() {
    echo -e "${CYAN}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warn() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

print_banner() {
    echo -e "${CYAN}${BOLD}"
    echo "================================================================"
    echo "       QR CODE ATTENDANCE MANAGEMENT SYSTEM (LINUX RUNNER)     "
    echo "================================================================"
    echo -e "${NC}"
}

# Get active port from .env or default to 3000
get_port() {
    if [ -f "$APP_DIR/.env" ]; then
        local env_port
        env_port=$(grep -E '^PORT=' "$APP_DIR/.env" | head -n1 | cut -d'=' -f2 | tr -d '\r\n ' )
        if [ -n "$env_port" ]; then
            echo "$env_port"
            return
        fi
    fi
    echo "3000"
}

# Retrieve primary IP address for remote access display
get_server_ip() {
    local ip
    if command -v hostname >/dev/null 2>&1; then
        ip=$(hostname -I 2>/dev/null | awk '{print $1}')
    fi
    if [ -z "$ip" ] && command -v ip >/dev/null 2>&1; then
        ip=$(ip route get 1.1.1.1 2>/dev/null | awk '{print $7}')
    fi
    if [ -z "$ip" ]; then
        echo "127.0.0.1"
    else
        echo "$ip"
    fi
}

# Check prerequisites: Node.js and npm
check_prerequisites() {
    log_info "Checking system environment..."

    if ! command -v node >/dev/null 2>&1; then
        log_error "Node.js is not installed or not found in PATH."
        echo ""
        echo "Please install Node.js (version 18 or newer):"
        echo "  - Ubuntu/Debian:  curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash - && sudo apt install -y nodejs"
        echo "  - RHEL/CentOS:    sudo dnf module install -y nodejs:20"
        echo "  - Arch Linux:     sudo pacman -S nodejs npm"
        echo ""
        exit 1
    fi

    local node_ver
    node_ver=$(node -v)
    log_success "Node.js detected: ${BOLD}${node_ver}${NC}"

    local node_major
    node_major=$(echo "$node_ver" | sed 's/v//' | cut -d'.' -f1)
    if [ "$node_major" -lt 18 ]; then
        log_warn "Node.js version is below v18 ($node_ver). Node.js v18+ is recommended."
    fi

    if ! command -v npm >/dev/null 2>&1; then
        log_error "npm is not installed or not found in PATH. Please install npm."
        exit 1
    fi

    local npm_ver
    npm_ver=$(npm -v)
    log_success "npm detected: ${BOLD}v${npm_ver}${NC}"
}

# Ensure .env file exists
check_environment_file() {
    if [ ! -f "$APP_DIR/.env" ]; then
        if [ -f "$APP_DIR/.env.example" ]; then
            log_warn ".env file not found. Creating .env from .env.example..."
            cp "$APP_DIR/.env.example" "$APP_DIR/.env"
            chmod 600 "$APP_DIR/.env" 2>/dev/null || true
            log_success ".env file generated successfully."
        else
            log_warn "Neither .env nor .env.example found. Generating default .env..."
            cat << 'EOF' > "$APP_DIR/.env"
PORT=3000
NODE_ENV=production
JWT_SECRET=qr_attendance_linux_server_secret_change_me_in_production
DB_DRIVER=sqlite
DB_HOST=127.0.0.1
DB_PORT=3306
DB_USER=root
DB_PASSWORD=
DB_NAME=qr_attendance_db
EOF
            chmod 600 "$APP_DIR/.env" 2>/dev/null || true
            log_success "Default .env created."
        fi
    fi
}

# Check and install npm dependencies
check_dependencies() {
    if [ ! -d "$APP_DIR/node_modules" ] || [ ! -f "$APP_DIR/node_modules/.package-lock.json" ] && [ ! -d "$APP_DIR/node_modules/express" ]; then
        log_info "Dependencies not found. Running 'npm install'..."
        npm install
        if [ $? -eq 0 ]; then
            log_success "Dependencies installed successfully."
        else
            log_error "npm install failed. Please inspect errors above."
            exit 1
        fi
    fi
}

# Check if process is currently running
is_running() {
    if [ -f "$PID_FILE" ]; then
        local pid
        pid=$(cat "$PID_FILE" 2>/dev/null)
        if [ -n "$pid" ] && kill -0 "$pid" 2>/dev/null; then
            return 0
        fi
    fi
    return 1
}

# ------------------------------------------------------------------------------
# Action Handlers
# ------------------------------------------------------------------------------

# Start in foreground
start_foreground() {
    print_banner
    check_prerequisites
    check_environment_file
    check_dependencies

    local port
    port=$(get_port)
    local ip
    ip=$(get_server_ip)

    echo ""
    echo -e "${GREEN}${BOLD}Server is starting up...${NC}"
    echo -e "  ➜ Local URL:    ${CYAN}http://localhost:${port}${NC}"
    echo -e "  ➜ Network URL:  ${CYAN}http://${ip}:${port}${NC}"
    echo -e "  ➜ Press ${BOLD}Ctrl + C${NC} to stop the server."
    echo ""

    exec node src/app.js
}

# Start as background daemon
start_background() {
    print_banner
    check_prerequisites
    check_environment_file
    check_dependencies

    if is_running; then
        local running_pid
        running_pid=$(cat "$PID_FILE")
        log_warn "Application is already running in background (PID: $running_pid)."
        exit 0
    fi

    # Check if PM2 is installed globally and prefer it if user has PM2
    if command -v pm2 >/dev/null 2>&1; then
        log_info "PM2 detected! Launching process via PM2..."
        pm2 start src/app.js --name "qr-attendance"
        log_success "App started with PM2."
        exit 0
    fi

    local port
    port=$(get_port)
    local ip
    ip=$(get_server_ip)

    log_info "Starting application in background..."
    nohup node src/app.js > "$LOG_FILE" 2>&1 &
    local new_pid=$!
    echo "$new_pid" > "$PID_FILE"

    sleep 1

    if kill -0 "$new_pid" 2>/dev/null; then
        log_success "Server running in background! (PID: ${BOLD}$new_pid${NC})"
        echo ""
        echo -e "  ➜ Local URL:    ${CYAN}http://localhost:${port}${NC}"
        echo -e "  ➜ Network URL:  ${CYAN}http://${ip}:${port}${NC}"
        echo -e "  ➜ Log File:     ${BOLD}$LOG_FILE${NC}"
        echo -e "  ➜ View Logs:    ${BOLD}./run.sh logs${NC}"
        echo -e "  ➜ Stop Server:  ${BOLD}./run.sh stop${NC}"
        echo ""
    else
        log_error "Server failed to stay alive. Check logs below:"
        echo "----------------------------------------"
        tail -n 25 "$LOG_FILE" 2>/dev/null || true
        echo "----------------------------------------"
        rm -f "$PID_FILE"
        exit 1
    fi
}

# Stop running background server
stop_server() {
    print_banner

    # Check PM2 first
    if command -v pm2 >/dev/null 2>&1; then
        if pm2 describe "qr-attendance" >/dev/null 2>&1; then
            log_info "Stopping application managed by PM2..."
            pm2 stop "qr-attendance"
            pm2 delete "qr-attendance" 2>/dev/null || true
            log_success "Application stopped via PM2."
            return 0
        fi
    fi

    if [ ! -f "$PID_FILE" ]; then
        log_warn "No PID file found ($PID_FILE). Is the server running in background?"
        return 0
    fi

    local pid
    pid=$(cat "$PID_FILE" 2>/dev/null)

    if [ -z "$pid" ] || ! kill -0 "$pid" 2>/dev/null; then
        log_warn "Process $pid is not active. Cleaning up PID file."
        rm -f "$PID_FILE"
        return 0
    fi

    log_info "Stopping background process (PID: $pid)..."
    kill -15 "$pid" 2>/dev/null || true

    local timeout=10
    local count=0
    while kill -0 "$pid" 2>/dev/null && [ "$count" -lt "$timeout" ]; do
        sleep 1
        count=$((count + 1))
    done

    if kill -0 "$pid" 2>/dev/null; then
        log_warn "Process did not terminate gracefully; forcing SIGKILL..."
        kill -9 "$pid" 2>/dev/null || true
    fi

    rm -f "$PID_FILE"
    log_success "Server stopped successfully."
}

# Show running status and health check
show_status() {
    print_banner
    local port
    port=$(get_port)
    local ip
    ip=$(get_server_ip)

    # Check PM2
    if command -v pm2 >/dev/null 2>&1; then
        if pm2 describe "qr-attendance" >/dev/null 2>&1; then
            echo -e "${GREEN}${BOLD}Status:${NC} Running under PM2 process manager"
            pm2 show "qr-attendance"
            return 0
        fi
    fi

    if is_running; then
        local pid
        pid=$(cat "$PID_FILE")
        echo -e "${GREEN}${BOLD}Status:${NC} Running in background (PID: ${BOLD}$pid${NC})"
        echo -e "  ➜ Local URL:   ${CYAN}http://localhost:${port}${NC}"
        echo -e "  ➜ Network URL: ${CYAN}http://${ip}:${port}${NC}"
        echo -e "  ➜ Log File:    ${BOLD}$LOG_FILE${NC}"

        # Probe health check endpoint if curl or wget is installed
        if command -v curl >/dev/null 2>&1; then
            echo ""
            log_info "Probing API health check (/api/health)..."
            local health_response
            health_response=$(curl -s -m 3 "http://127.0.0.1:${port}/api/health" 2>/dev/null || true)
            if [ -n "$health_response" ]; then
                echo -e "${GREEN}Health Response:${NC} $health_response"
            else
                log_warn "API health endpoint did not respond yet."
            fi
        fi
    else
        echo -e "${YELLOW}${BOLD}Status:${NC} Server is currently ${RED}${BOLD}STOPPED${NC}."
    fi
}

# Tail logs
view_logs() {
    if command -v pm2 >/dev/null 2>&1 && pm2 describe "qr-attendance" >/dev/null 2>&1; then
        pm2 logs "qr-attendance"
        return 0
    fi

    if [ ! -f "$LOG_FILE" ]; then
        log_warn "Log file ($LOG_FILE) does not exist yet."
        exit 0
    fi
    log_info "Streaming logs from $LOG_FILE (Press Ctrl+C to exit)..."
    tail -f -n 50 "$LOG_FILE"
}

# Explicit dependency install
run_install() {
    print_banner
    check_prerequisites
    check_environment_file
    log_info "Installing / updating dependencies..."
    npm install
    log_success "Dependencies up to date."
}

# Print help guide
show_help() {
    print_banner
    echo "Usage: ./run.sh [command]"
    echo ""
    echo "Commands:"
    echo "  (none) / start   Start server in foreground (default interactive mode)"
    echo "  daemon           Start server as background daemon (creates server.log)"
    echo "  stop             Stop the background server process"
    echo "  restart          Restart the background server"
    echo "  status           Check if server is active and test /api/health"
    echo "  logs             View and follow background logs (tail -f server.log)"
    echo "  install          Install / reinstall npm dependencies"
    echo "  help             Show this help menu"
    echo ""
    echo "Examples:"
    echo "  chmod +x run.sh"
    echo "  ./run.sh              # Run directly in terminal"
    echo "  ./run.sh daemon       # Run in background on Linux server"
    echo "  ./run.sh status       # Check server status"
    echo "  ./run.sh logs         # Follow live server output"
    echo "  ./run.sh stop         # Stop background server"
    echo ""
}

# ------------------------------------------------------------------------------
# Argument Dispatcher
# ------------------------------------------------------------------------------
case "${1:-start}" in
    start|run)
        start_foreground
        ;;
    daemon|background|-d|--daemon)
        start_background
        ;;
    stop)
        stop_server
        ;;
    restart)
        stop_server
        sleep 1
        start_background
        ;;
    status)
        show_status
        ;;
    logs|log)
        view_logs
        ;;
    install|setup)
        run_install
        ;;
    help|--help|-h)
        show_help
        ;;
    *)
        log_error "Unknown option: $1"
        echo ""
        show_help
        exit 1
        ;;
esac
